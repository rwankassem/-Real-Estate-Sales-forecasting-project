from django.contrib import admin
from .models import HousePrediction
# Register your models here.
admin.site.register(HousePrediction)