# views.py
import joblib
import os
from django.conf import settings
from django.shortcuts import render, redirect
from .forms import HousePredictionForm
from .models import HousePrediction
import numpy as np

def load_scalers_and_model():
    # Load all scalers and encoders
    scalers = {
        'square_footage': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'sqft_scaler.pkl')),
        'bedrooms': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'bedrooms_scaler.pkl')),
        'bathrooms': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'bathrooms_scaler.pkl')),
        'year_built': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'year_built_scaler.pkl')),
        'zip': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'zip_scaler.pkl')),
    }
    
    encoders = {
        'house_type': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'house_type_encoder.pkl')),
        'state': joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'state_encoder.pkl')),
    }
    
    model = joblib.load(os.path.join(settings.BASE_DIR, 'ml_models', 'model.pkl'))
    
    return scalers, encoders, model

def predict_price(request):
    if request.method == 'POST':
        form = HousePredictionForm(request.POST)
        if form.is_valid():
            # Load the scalers, encoders and model
            scalers, encoders, model = load_scalers_and_model()
            
            # Get form data
            data = form.cleaned_data
            
            # Prepare features in the correct order
            features = [
                data['zip_code'],
                data['year_built'],
                data['bathrooms'],
                data['bedrooms'],
                data['square_footage'],
                # City frequency (placeholder - in a real app you'd calculate this)
                0.0,  # This should be replaced with actual city frequency calculation
                data['state'],
                -0.292337,  # Date Added (fixed value as per requirement)
                491.942298043151,  # Status Change Date (fixed value as per requirement)
                data['house_type']
            ]
            
            # Transform features
            features[0] = scalers['zip'].transform([[features[0]]])[0][0]  # Zip
            features[1] = scalers['year_built'].transform([[features[1]]])[0][0]  # Year Built
            features[2] = scalers['bathrooms'].transform([[features[2]]])[0][0]  # Bathrooms
            features[3] = scalers['bedrooms'].transform([[features[3]]])[0][0]  # Bedrooms
            features[4] = scalers['square_footage'].transform([[features[4]]])[0][0]  # Square Footage
            features[6] = encoders['state'].transform([features[6]])[0]  # State
            features[9] = encoders['house_type'].transform([features[9]])[0]  # House Type
            
            # Make prediction
            prediction = model.predict([features])[0]
            
            # Save prediction to database
            house_pred = HousePrediction(
                zip_code=data['zip_code'],
                year_built=data['year_built'],
                bathrooms=data['bathrooms'],
                bedrooms=data['bedrooms'],
                square_footage=data['square_footage'],
                city=data['city'],
                state=data['state'],
                house_type=data['house_type'],
                predicted_price=prediction
            )
            house_pred.save()
            
            return render(request, 'prediction_result.html', {
                'prediction': prediction,
                'form_data': data
            })
    else:
        form = HousePredictionForm()
    
    return render(request, 'predict_price.html', {'form': form})