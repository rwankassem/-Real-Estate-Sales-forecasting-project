from django.db import models

# Create your models here.
# models.py
from django.db import models

class HousePrediction(models.Model):
    zip_code = models.CharField(max_length=10)
    year_built = models.IntegerField()
    bathrooms = models.FloatField()
    bedrooms = models.IntegerField()
    square_footage = models.FloatField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=2)
    house_type = models.CharField(max_length=50)
    predicted_price = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Prediction for {self.city}, {self.state}"