# forms.py
from django import forms

HOUSE_TYPES = [
    ('Single-Family Home', 'Single-Family Home'),
    ('Townhouse', 'Townhouse'),
    ('Apartment/Condo', 'Apartment/Condo'),
    ('Other', 'Other'),
]

STATES = [
    ('MD','MD'),
    ('VA', 'VA'),
    ('DC', 'DC'),
    ('WV', 'WV'),
    # Add more states as needed
]
CITIES=[
    (2.444435,'Baltimore'),
    (1.139041,'Alexandria'),
    (0.101596,'Arlington'),
    (0.829868,'Washington'),
    (-0.214447,'Woodbridge'),
    (-0.338116,'other')


]

class HousePredictionForm(forms.Form):
    zip_code = forms.CharField(label='Zip Code', max_length=10)
    year_built = forms.IntegerField(label='Year Built', min_value=1800, max_value=2025)
    bathrooms = forms.FloatField(label='Bathrooms', min_value=0.5, max_value=10)
    bedrooms = forms.IntegerField(label='Bedrooms', min_value=1, max_value=10)
    square_footage = forms.FloatField(label='Square Footage', min_value=100)
    city = forms.ChoiceField(label='City',choices=CITIES)
    state = forms.ChoiceField(label='State', choices=STATES)
    house_type = forms.ChoiceField(label='House Type', choices=HOUSE_TYPES)